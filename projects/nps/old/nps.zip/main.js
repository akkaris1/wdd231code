// main.js
// This is the main JavaScript file that runs when the page loads
// It imports functions from other modules and uses them to populate the page

// Import the data and functions we need
import { getParkData, parkInfoLinks } from "./parkService.mjs";
import setHeaderFooter from "./setHeaderFooter.mjs";
import { mediaCardTemplate } from "./templates.mjs";

// Get the park data (loaded from parkData.json via parkService.mjs)
const parkData = getParkData();

/**
 * setParkIntro - Sets the introductory section with park name and description
 * This section appears below the hero banner
 * 
 * @param {Object} data - Park data object
 */
function setParkIntro(data) {
  const introEl = document.querySelector(".intro");
  introEl.innerHTML = `<h1>${data.fullName}</h1>
  <p>${data.description}</p>`;
}

/**
 * setParkInfoLinks - Creates the three info cards
 * (Current Conditions, Fees and Passes, Visitor Centers)
 * 
 * @param {Array} data - Array of info link objects with name, link, image, description
 */
function setParkInfoLinks(data) {
  const infoEl = document.querySelector(".info");
  // Map each info link to HTML using mediaCardTemplate, then join into single string
  const html = data.map(mediaCardTemplate);
  // Insert the HTML at the beginning of the .info element
  infoEl.insertAdjacentHTML("afterbegin", html.join(""));
}

// Execute all the functions to populate the page
// These run when the page loads

// 1. Set up header (disclaimer, title, hero banner) and footer (contact info)
setHeaderFooter(parkData);

// 2. Set up the intro section (park name and description)
setParkIntro(parkData);

// 3. Set up the three info link cards
setParkInfoLinks(parkInfoLinks);
